public class Black {
    public static String reverse(String str) {
        String reversedStr = "";
        for (int i = 0; str.length() > i; i++) {
            reversedStr += str.charAt(str.length() - i - 1);
        }
        return reversedStr;
    }
    public static String doubleChar(String str) {
        String doubledChar = "";
        for (int i = 0; i < str.length(); i++) {
            doubledChar += str.charAt(i);
            doubledChar += str.charAt(i);
        }
        return doubledChar;
    }
    public static String doubleStr(String str) {
        return str + str;
    }
    public static String shiftToRight(String str) {
        String shiftedString = "";
        shiftedString += str.charAt(str.length() - 1);
        shiftedString += str.substring(0, str.length() - 1);
        return shiftedString;
    }
    public static String turnedAlphabet(String str) {
        String resultString = "";
        int temp;
        char tempChar;
        int[] tempCharArr = new int[26];
        int counter = 122;
        for (int i = 0; i < 26; i++) {
            tempCharArr[i] = counter;
            counter--;
        }
        for (int i = 0; str.length() > i; i++) {
            temp = str.charAt(i);
            for (int j = 0; tempCharArr.length > j; j++) {
                if (temp == tempCharArr[j]) {
                    temp = Math.abs(tempCharArr[25 - j]);
                    break;
                }
            }
            tempChar = (char)temp;
            resultString += tempChar;
        }
        return resultString;
    }
}
