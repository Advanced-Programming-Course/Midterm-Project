public class Vertex {
    String arrow;
    int num;
    String color;
    String input;
    Vertex(String arrow , int num , String color, String input) {
        this.arrow = arrow;
        this.num = num;
        this.color = color;
        this.input = input;
    }
    public static String black(int num,String stringInput) {
        String result = "";
        switch (num) {
            case 1:
                result = Black.reverse(stringInput);
                break;
            case 2:
                result = Black.doubleChar(stringInput);
                break;
            case 3:
                result = Black.doubleStr(stringInput);
                break;
            case 4:
                result = Black.shiftToRight(stringInput);
                break;
            case 5:
                result = Black.turnedAlphabet(stringInput);
                break;
        }
        return result;
    }
    public static String white(int num,String stringInput1,String stringInput2) {
        String result = "";
        switch (num) {
            case 1:
                result = White.decussateString(stringInput1,stringInput2);
                break;
            case 2:
                result = White.reverseString(stringInput1,stringInput2);
                break;
            case 3:
                result = White.sumString(stringInput1,stringInput2);
                break;
            case 4:
                result = White.evenString(stringInput1,stringInput2);
                break;
            case 5:
                result = White.combineString(stringInput1,stringInput2);
        }
        return result;
    }
}