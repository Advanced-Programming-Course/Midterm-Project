import java.util.Scanner;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random r = new Random();
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        String string = scan.next();
        System.out.println();
        int[][] Matrix = new int[n][n];

        // making the required magical matrix
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++){
                Matrix[i][j] = r.nextInt(1 , 6);
            }
        }

        // giving values to our matrix
        Vertex[][] magicalMatrix = new Vertex[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++){
                //green
                if (( i == 0 && j != n-1) || (j == 0 && i != n-1)){
                    magicalMatrix[i][j] = new Vertex("Black" , Matrix[i][j] , "Green",string);
                }
                //yellow
                else if ((i == 0 && j == n-1) || (j == 0 && i == n-1)){
                    magicalMatrix[i][j] = new Vertex("Black" , Matrix[i][j] , "Yellow", string);
                }
                //blue
                else if ((i != 0 && j != n-1) || (j != 0 && i != n-1)){
                    magicalMatrix[i][j] = new Vertex("Black" , Matrix[i][j] , "Blue", string);
                }
                //pink
                if (( i != 0 && j == n-1) || (j != 0 && i == n-1)){
                    magicalMatrix[i][j] = new Vertex("White" , Matrix[i][j] , "Pink",string);
                }
            }
        }
        String[][] resultMatrix = new String[n][n];

        printMatrix(magicalMatrix);

        System.out.println("\n"+calculateSquares(resultMatrix,magicalMatrix,n));
    }


    public static String calculateSquares(String[][] resultMatrix,Vertex[][] magicalMatrix,int n) {

        resultMatrix[0][0] = magicalMatrix[0][0].input;

        //green squares (row)
        for (int i = 0; resultMatrix.length-1 > i; i++) {
            resultMatrix[0][i+1] = Vertex.black(magicalMatrix[0][i].num,resultMatrix[0][i]);
        }
        //green squares (column)
        for (int i = 0; resultMatrix.length-1 > i; i++) {
            resultMatrix[i+1][0] = Vertex.black(magicalMatrix[i][0].num,resultMatrix[i][0]);
        }


        //blue squares (row)
        for (int i = 0; resultMatrix.length-2 > i; i++) {
            for (int j = 0; resultMatrix.length-1 > j; j++) {
                resultMatrix[i+1][j+1] = Vertex.black(magicalMatrix[i+1][j].num,resultMatrix[i+1][j]);
            }
        }
        //blue squares (column)
        for (int i = 0; resultMatrix.length-2 > i; i++) {
            for (int j = 0; resultMatrix.length-1 > j; j++) {
                resultMatrix[j+1][i+1] = Vertex.black(magicalMatrix[j][i+1].num,resultMatrix[j][i+1]);
            }
        }


        //yellow squares
        resultMatrix[0][n-1] = Vertex.black(magicalMatrix[0][n-1].num,resultMatrix[0][n-1]);
        resultMatrix[n-1][0] = Vertex.black(magicalMatrix[n-1][0].num,resultMatrix[n-1][0]);



        //pink squares (row)
        for (int i = 0; resultMatrix.length-2 > i; i++) {
            resultMatrix[n-1][i+1] = Vertex.white(magicalMatrix[n-1][i+1].num,resultMatrix[n-1][i],resultMatrix[n-1][i+1]);
        }
        //pink squares (column)
        for (int i = 0; resultMatrix.length-2 > i; i++) {
            resultMatrix[i+1][n-1] = Vertex.white(magicalMatrix[i+1][n-1].num,resultMatrix[i][n-1],resultMatrix[i][n-1]);
        }

        return Vertex.white(magicalMatrix[n-1][n-1].num,resultMatrix[n-1][n-2],resultMatrix[n-2][n-1]);
    }

    public static void printMatrix(Vertex[][] magicalMatrix) {
        for (int i = 0; magicalMatrix.length > i; i++) {
            for (int j = 0; magicalMatrix.length > j; j++) {
                System.out.print(magicalMatrix[i][j].num+" ");
            }
            System.out.println();
        }
    }
}