public class White {
    public static String decussateString(String str1 , String str2){ //1
    int len1 = str1.length();
    int len2 = str2.length();
    String decussatedString = "";

    for (int i = 0; Math.max(len1,len2) > i; i++) {
        if (len1 > i) {
            decussatedString += str1.charAt(i);
        }
        if (len2 > i) {
            decussatedString += str2.charAt(i);
        }
    }
    return decussatedString;
}
    public static String reverseString(String str1 , String str2){ //2
        String reversedString = "";
        for (int i = 0; i < str2.length(); i++){
            reversedString += str2.charAt(str2.length() - i - 1);
        }
        return str1 + reversedString;
    }
    public static String sumString(String str1 , String str2){ //3
        int len1 = str1.length();
        int len2 = str2.length();
        String summedString = "";
        for (int i = 0; Math.max(len1,len2) > i; i++) {
            if (len1 > i) {
                summedString += str1.charAt(i);
            }
            if (len2 > i) {
                summedString += str2.charAt(len2 - i - 1);
            }
        }
        return summedString;
    }
    public static String evenString(String str1 , String str2){ //4
        String result = "";
        if (str1.length() % 2 == 0){
            result += str1;
        }
        else {
            result += str2;
        }
        return result;
    }

    public static String combineString(String string1 , String string2){
        StringBuilder encrypted = new StringBuilder();
        int min = Math.min(string1.length(), string2.length());
        for (int i = 0; i < min; i++) {
            char char1 = string1.charAt(i);
            char char2 = string2.charAt(i);
            int sum = (char1 - 'a' + char2 - 'a') % 26 + 'a';
            encrypted.append((char) sum);
        }
        if (string1.length() > string2.length()) {
            encrypted.append(string1.substring(string2.length()));
        } else if (string2.length() > string1.length()) {
            encrypted.append(string2.substring(string1.length()));
        }
        return encrypted.toString();
    }
}
