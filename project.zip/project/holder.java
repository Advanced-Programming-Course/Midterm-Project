public class Holder {
    private String output2;
    private String output1;

    public Holder()
    {
        output1 = "";
        output2 = "";
    }

    public String getOutput2() {
        return output2;
    }

    public void setOutput2(String output2) {
        this.output2 = output2;
    }

    public String getOutput1() {
        return output1;
    }

    public void setOutput1(String output1) {
        this.output1 = output1;
    }
}