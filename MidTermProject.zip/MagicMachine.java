import java.util.Random;
public class MagicMachine{
//    int[] cellType = {1/*green*/, 2/*yellow*/, 3/*blue*/, 4/*pink*/};
    private Random random = new Random();
    private int size;
    private int[][] cells;
    public String inputStr;
    public MagicMachine(int size, String inputStr) {
        setSize(size);
        this.inputStr = inputStr;
        setCells(size, random);
    }
    private void setSize(int size){
        this.size = size;
    }
    private int getSize() {
        return size;
    }
    private void setCells(int size, Random random) {
        this.cells = new int[getSize()][getSize()];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                cells[i][j] = random.nextInt(5) + 1;
            }
        }
    }
//    private int[][] getCells() {
//        return cells;
//    }
    public void getCells() {
        for (int i = 0; i < cells.length; i++) {
            for (int j = 0; j < cells[i].length; j++) {
                System.out.print(cells[i][j] + " ");
            }
            System.out.println();
        }
    }
    private String blackFunctionChoise(String str, int type) {
        switch (type) {
            case 1:
                return new StringBuilder(str).reverse().toString();
            case 2:
                StringBuilder repeated = new StringBuilder();
                for(char c: str.toCharArray()) {
//                    new StringBuilder().append(c).append(c);
                    repeated.append(c).append(c);
                }
                return repeated.toString();
            case 3:
                return str + str;
            case 4:
                return rightShift(str);
            case 5:
                return charShifter(str);
            default:
                return str;
        }
    }
    private String rightShift(String str) {
        String shifted = str.charAt(str.length() - 1) +str.substring(0, str.length() - 1);
        return shifted;
    }
    private String charShifter(String str) {
        StringBuilder shifted  = new StringBuilder();
        for(char c : str.toCharArray()) {
            char newShifted = (char) ('a' + (c - 'a' + 1) % 26);
            shifted.append(newShifted);
        }
        return shifted.toString();
    }
    private String witheFunctionChoise(String str1, String str2, int type) {
        switch (type) {
            case 1:
                return combineStrings(str1, str2);
            case 2:
                return str1 + reverser(str2);
            case 3:
                return patterOfChars(str1, str2);
            case 4:
                return oddPrint(str1, str2);
            case 5:
                return sumMod26(str1, str2);
            default:
                return str1 + str2;
        }
    }
    private String combineStrings(String str1, String str2) {
        StringBuilder outPut = new StringBuilder();
        for (int i = 0; i < Math.max(str1.length(), str2.length()); i++) {
            if (i < str1.length())
                outPut.append(str1.charAt(i));
            if (i < str2.length())
                outPut.append(str2.charAt(i));
        }
        return outPut.toString();
    }
    private String reverser(String str) {
        StringBuilder revers = new StringBuilder(str).reverse();
        return revers.toString();
    }
    private String patterOfChars(String str1, String str2) {
        StringBuilder out = new StringBuilder();
//        int minLength = Math.min(str1.length(), str2.length());
        int maxLength = Math.max(str1.length(), str2.length());
//        for (int i = 0; i < minLength; i++) {
//            out.append(str1.charAt(i));
//            out.append(str2.charAt(maxLength - 1 - i));
//        }
//        return out.toString();
        for (int i = 0; i < maxLength; i++) {
            if (i < str1.length()) {
                out.append(str1.charAt(i));
            }
            if (i < str2.length()) {
                out.append(str2.charAt(i));
            }
        }
        return out.toString();
    }
    private String oddPrint(String str1, String str2) {
        if (str1.length() % 2 == 0) {
            return str1;
        } else {
            return str2;
        }
    }
    private String sumMod26( String str1, String str2) {
        StringBuilder out = new StringBuilder();
        int minLength = Math.min(str1.length(), str2.length());
        int maxLength = Math.max(str1.length(), str2.length());
        for (int i = 0; i < minLength; i++) {
            char char1 = str1.charAt(i);
            char char2 = str2.charAt(i);
            char sum = (char) ((char1 - 'a' + char2 - 'a') % 26 + 'a');
            out.append(sum);
        }
        if (str1.length() != str2.length()) {
            out.append(maxLength == str1.length() ? str2.substring(minLength) : str1.substring(minLength));
        }
        return out.toString();
    }

    private String greenAndYellowAndBlueType(String str, int type) {
        return blackFunctionChoise(str, type);
    }
    private String pinkType(String str1, String str2, int type) {
        return witheFunctionChoise(str1, str2, type);
    }
    public String outPut(String str) {
        String[] resRow = new String[size];
        String[] resColumn = new String[size];
        for (int i = 0; i < resRow.length; i++) {
            resRow[i] = str;
        }
        for (int i = 0; i < resColumn.length; i++) {
            resColumn[i] = str;
        }
        for (int i = 0; i < size - 1; i++) {
            resRow[0] = blackFunctionChoise(str, cells[0][i]);
        }
        for (int i = 0; i < size - 1; i++) {
            resColumn[0] = blackFunctionChoise(str, cells[i][0]);
        }
        for (int i = 1; i < size - 1; i++) {
            for (int j = 0; j < size + i - 1; j++) {
                if(i > j){
                    resRow[i] = blackFunctionChoise(str, cells[i - 1][0]);
                }else{
                    resRow[i] = blackFunctionChoise(str, cells[i][j - i]);
                }
            }
        }
        for (int i = 1; i < size - 1; i++) {
            for (int j = 0; j < size + i - 1; j++) {
                if(i > j){
                    resColumn[i] = blackFunctionChoise(str, cells[0][i - 1]);
                }else{
                    resRow[i] = blackFunctionChoise(str, cells[i][j - i]);
                }
            }
        }
        String firstWithe = resRow[0];
        for (int i = 1; i < size - 3; i++) {
            firstWithe = witheFunctionChoise(resRow[i], firstWithe, cells[i][size - 1]);
        }
        String secondWithe = resColumn[0];
        for (int i = 1; i < size - 3; i++) {
            secondWithe = witheFunctionChoise(resColumn[i], firstWithe, cells[i][size - 1]);
        }
        return witheFunctionChoise(firstWithe, secondWithe, cells[size - 1][size - 1]);
    }
}