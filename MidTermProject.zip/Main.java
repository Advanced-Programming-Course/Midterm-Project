import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        scanner.nextLine();
        String inputString = scanner.nextLine();
        MagicMachine machine = new MagicMachine(n, inputString);
//        machine.getCells();
        System.out.println();
        System.out.println(machine.outPut(machine.inputStr));
    }
}
