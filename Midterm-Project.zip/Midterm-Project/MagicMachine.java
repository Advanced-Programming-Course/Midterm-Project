import java.util.Random;
import java.util.Scanner;

public class MagicMachine {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        String inputString = scanner.nextLine();

        Random random = new Random();
        int[][] magicArray = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                magicArray[i][j] = random.nextInt(1, 2);
            }
        }

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.print(magicArray[i][j] + "\t");
            }
            System.out.println();
        }

        String output = operateMagicMachine(n, magicArray, inputString);
        System.out.println(output);
    }

    public static String operateMagicMachine(int n, int[][] magicArray, String input) {
        String resultString = input;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if ((i == n - 1 && j != 0) || (i != 0 && j == n - 1)) {
                    if (magicArray[i][j] >= 1 && magicArray[i][j] <= 5) {
                        resultString = processWhiteFunction(resultString, resultString, magicArray[i][j]);
                    }
                } else {
                    if (magicArray[i][j] >= 1 && magicArray[i][j] <= 5) {
                        resultString = processBlackFunction(resultString, magicArray[i][j]);
                    }
                }
            }
        }
        return resultString;
    }

    public static String processBlackFunction(String str, int num) {
        StringBuilder result = new StringBuilder();
        switch (num) {
            case 1:
                str = new StringBuilder(str).reverse().toString();
                break;
            case 2:
                StringBuilder repeatedChars = new StringBuilder();
                for (char c : str.toCharArray()) {
                    repeatedChars.append(c).append(c);
                }
                str = repeatedChars.toString();
                break;
            case 3:
                str += str;
                break;
            case 4:
                char[] charArray = str.toCharArray();
                char temp = charArray[charArray.length - 1];
                for (int i = charArray.length - 1; i > 0; i--) {
                    charArray[i] = charArray[i - 1];
                }
                charArray[0] = temp;
                for (char value : charArray) {
                    result.append(value);
                }
                str = result.toString();
                break;
            case 5:
                for (int i = 0; i < str.length(); i++) {
                    char c = str.charAt(i);
                    if (Character.isLetter(c)) {
                        char reversedChar = (char) ('a' + ('z' - Character.toLowerCase(c)));
                        result.append(reversedChar);
                    } else {
                        result.append(c);
                    }
                }
                str = result.toString();
                break;
        }
        return str;
    }

    public static String processWhiteFunction(String str1, String str2, int num) {
        String resultString = null;
        StringBuilder result = new StringBuilder();
        int len1 = str1.length();
        int len2 = str2.length();
        int minLen = Math.min(len1, len2);

        switch (num) {
            case 1:
                for (int i = 0; i < minLen; i++) {
                    result.append(str1.charAt(i));
                    result.append(str2.charAt(i));
                }
                if (len1 > len2) {
                    result.append(str1.substring(minLen));
                } else if (len2 > len1) {
                    result.append(str2.substring(minLen));
                }
                resultString = result.toString();
                break;
            case 2:
                String reversedStr2 = new StringBuilder(str2).reverse().toString();
                resultString = str1 + reversedStr2;
                break;
            case 3:
                for (int i = 0; i < minLen; i++) {
                    result.append(str1.charAt(i));
                    result.append(str2.charAt(len2 - i - 1));
                }
                if (len1 > len2) {
                    result.append(str1.substring(minLen));
                } else if (len2 > len1) {
                    result.append(new StringBuilder(str2.substring(0, len2 - minLen)).reverse());
                }
                resultString = result.toString();
                break;
            case 4:
                resultString = str1.length() % 2 == 0 ? str1 : str2;
                break;
            case 5:
                for (int i = 0; i < minLen; i++) {
                    int sum = (str1.charAt(i) - 'a' + 1) + (str2.charAt(i) - 'a' + 1);
                    result.append((char) ((sum - 1) % 26 + 'a'));
                }
                if (len1 > len2) {
                    result.append(str1.substring(minLen));
                } else if (len2 > len1) {
                    result.append(str2.substring(minLen));
                }
                resultString = result.toString();
                break;
        }
        return resultString;
    }
}